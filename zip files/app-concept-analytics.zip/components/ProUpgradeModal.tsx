import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, Zap, BarChart3, Image as ImageIcon, FileText, Crown, CreditCard, Lock, ArrowLeft, Loader2, ShieldCheck } from 'lucide-react';

interface ProUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

export const ProUpgradeModal: React.FC<ProUpgradeModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  const [step, setStep] = useState<'features' | 'payment' | 'processing' | 'success'>('features');
  
  // Payment Form State
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState('');

  useEffect(() => {
    if (isOpen) {
        setStep('features');
        // Reset form
        setCardNumber('');
        setExpiry('');
        setCvc('');
        setName('');
    }
  }, [isOpen]);

  const handleCardInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) value = value.slice(0, 16);
    // Add spaces
    const formatted = value.match(/.{1,4}/g)?.join(' ') || value;
    setCardNumber(formatted);
  };

  const handleExpiryInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.slice(0, 4);
    if (value.length > 2) value = value.slice(0, 2) + '/' + value.slice(2);
    setExpiry(value);
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    
    // Simulate API latency
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    setStep('success');
    
    // Wait for success animation
    setTimeout(() => {
        onUpgrade();
    }, 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 w-full max-w-lg rounded-3xl shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col min-h-[500px]">
        
        {/* Decorative Background for all steps */}
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-br from-neutral-900 via-neutral-800 to-black dark:from-neutral-950 dark:via-black dark:to-neutral-900 z-0"></div>
        <div className="absolute top-0 left-0 right-0 h-32 opacity-30 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-yellow-600 via-transparent to-transparent z-0"></div>

        {/* Close Button */}
        {step !== 'processing' && step !== 'success' && (
            <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 text-white rounded-full transition-all z-20 backdrop-blur-md"
            >
            <X size={20} />
            </button>
        )}

        {/* STEP 1: FEATURES */}
        {step === 'features' && (
            <div className="relative z-10 pt-10 px-8 pb-8 flex flex-col h-full">
                {/* Icon */}
                <div className="mx-auto w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center shadow-xl shadow-yellow-500/20 mb-6 rotate-3 border-4 border-white dark:border-neutral-800">
                    <Crown size={40} className="text-white" fill="currentColor" />
                </div>

                <div className="text-center mb-8">
                    <h2 className="text-2xl font-black text-neutral-900 dark:text-white uppercase tracking-tight mb-2">
                        Strategia-X <span className="text-yellow-600 dark:text-yellow-500">PRO</span>
                    </h2>
                    <p className="text-neutral-500 dark:text-neutral-400 text-sm">
                        Unlock professional-grade market intelligence.
                    </p>
                </div>

                {/* Features List */}
                <div className="space-y-4 mb-8">
                    <div className="flex items-center gap-4 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                        <div className="p-2 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-lg">
                            <BarChart3 size={20} />
                        </div>
                        <div>
                            <h4 className="font-bold text-neutral-900 dark:text-white text-sm">Deep Dive Analytics</h4>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">12-Month Growth Projections & SWOT.</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg">
                            <ImageIcon size={20} />
                        </div>
                        <div>
                            <h4 className="font-bold text-neutral-900 dark:text-white text-sm">Generative Concept Art</h4>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">Unlimited AI-generated 4K visualizations.</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                        <div className="p-2 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-lg">
                            <FileText size={20} />
                        </div>
                        <div>
                            <h4 className="font-bold text-neutral-900 dark:text-white text-sm">Professional Exports</h4>
                            <p className="text-xs text-neutral-500 dark:text-neutral-400">Download PDF Reports, CSV & JSON data.</p>
                        </div>
                    </div>
                </div>

                {/* CTA */}
                <div className="mt-auto">
                    <button 
                        onClick={() => setStep('payment')}
                        className="w-full py-4 rounded-xl bg-gradient-to-r from-yellow-500 to-yellow-700 hover:from-yellow-400 hover:to-yellow-600 text-white font-bold uppercase tracking-widest shadow-lg shadow-yellow-600/30 hover:shadow-yellow-600/50 hover:scale-[1.02] active:scale-95 transition-all duration-200 flex items-center justify-center gap-2 group"
                    >
                        <Zap size={18} fill="currentColor" className="group-hover:text-white" />
                        Unlock Lifetime Access - $49
                    </button>
                    <p className="text-center text-[10px] text-neutral-400 mt-4 uppercase tracking-wider font-medium">
                        One-time payment • No recurring fees
                    </p>
                </div>
            </div>
        )}

        {/* STEP 2: PAYMENT */}
        {step === 'payment' && (
             <div className="relative z-10 pt-6 px-8 pb-8 h-full flex flex-col">
                 {/* Back Button */}
                 <button 
                    onClick={() => setStep('features')}
                    className="absolute top-6 left-6 text-white/70 hover:text-white transition-colors flex items-center gap-1 text-xs font-bold uppercase tracking-wider"
                 >
                     <ArrowLeft size={16} /> Back
                 </button>

                 <div className="text-center mb-8 mt-8">
                     <h2 className="text-xl font-bold text-white uppercase tracking-wide flex items-center justify-center gap-2">
                         <Lock size={18} /> Secure Checkout
                     </h2>
                 </div>

                 <div className="bg-neutral-50 dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 mb-6">
                     <div className="flex justify-between items-center mb-2">
                         <span className="text-sm font-bold text-neutral-900 dark:text-white">Strategia-X PRO</span>
                         <span className="text-sm font-bold text-neutral-900 dark:text-white">$49.00</span>
                     </div>
                     <div className="flex justify-between items-center text-xs text-neutral-500 dark:text-neutral-400">
                         <span>Lifetime Membership</span>
                         <span>One-time</span>
                     </div>
                 </div>

                 <form onSubmit={handleProcessPayment} className="space-y-4">
                     <div>
                         <label className="block text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-1.5">Card Number</label>
                         <div className="relative">
                             <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={18} />
                             <input 
                                type="text" 
                                value={cardNumber}
                                onChange={handleCardInput}
                                placeholder="0000 0000 0000 0000"
                                className="w-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg py-3 pl-10 pr-4 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 font-mono text-sm"
                                required
                             />
                         </div>
                     </div>

                     <div className="grid grid-cols-2 gap-4">
                         <div>
                             <label className="block text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-1.5">Expiry</label>
                             <input 
                                type="text" 
                                value={expiry}
                                onChange={handleExpiryInput}
                                placeholder="MM/YY"
                                className="w-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg py-3 px-4 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 font-mono text-sm text-center"
                                required
                             />
                         </div>
                         <div>
                             <label className="block text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-1.5">CVC</label>
                             <input 
                                type="text" 
                                value={cvc}
                                onChange={(e) => setCvc(e.target.value.slice(0, 4))}
                                placeholder="123"
                                className="w-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg py-3 px-4 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 font-mono text-sm text-center"
                                required
                             />
                         </div>
                     </div>

                     <div>
                         <label className="block text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-1.5">Cardholder Name</label>
                         <input 
                            type="text" 
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="JOHN DOE"
                            className="w-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg py-3 px-4 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500 text-sm uppercase"
                            required
                         />
                     </div>

                     <button 
                        type="submit"
                        className="w-full py-4 mt-4 rounded-xl bg-gradient-to-r from-yellow-500 to-yellow-700 hover:from-yellow-400 hover:to-yellow-600 text-white font-bold uppercase tracking-widest shadow-lg shadow-yellow-600/30 hover:shadow-yellow-600/50 hover:scale-[1.02] active:scale-95 transition-all duration-200 flex items-center justify-center gap-2"
                     >
                         Pay $49.00
                     </button>
                     
                     <div className="flex items-center justify-center gap-2 text-neutral-400 text-[10px] uppercase tracking-wider mt-2">
                        <ShieldCheck size={12} />
                        <span>Encrypted Payment Processing</span>
                     </div>
                 </form>
             </div>
        )}

        {/* STEP 3: PROCESSING */}
        {step === 'processing' && (
            <div className="relative z-10 flex flex-col items-center justify-center h-full min-h-[500px] text-center px-8">
                <Loader2 className="w-16 h-16 text-yellow-500 animate-spin mb-6" />
                <h3 className="text-xl font-bold text-neutral-900 dark:text-white uppercase tracking-wide mb-2">Processing Payment</h3>
                <p className="text-neutral-500 text-sm">Please do not close this window...</p>
            </div>
        )}

        {/* STEP 4: SUCCESS */}
        {step === 'success' && (
             <div className="relative z-10 flex flex-col items-center justify-center h-full min-h-[500px] text-center px-8">
                 <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-green-500/30 animate-in zoom-in duration-300">
                     <CheckCircle2 size={40} className="text-white" />
                 </div>
                 <h3 className="text-2xl font-black text-neutral-900 dark:text-white uppercase tracking-wide mb-2">Upgrade Complete!</h3>
                 <p className="text-neutral-600 dark:text-neutral-300 text-sm max-w-xs mx-auto mb-8">
                     You now have lifetime access to Strategia-X Pro features.
                 </p>
                 <div className="text-xs text-neutral-400 font-mono uppercase tracking-widest">Redirecting...</div>
             </div>
        )}

      </div>
    </div>
  );
};