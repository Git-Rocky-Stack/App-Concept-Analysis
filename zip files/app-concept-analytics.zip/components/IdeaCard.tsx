import React, { useState } from 'react';
import { AppIdea, AppCategory } from '../types';
import { TrendingUp, DollarSign, Users, Heart, Scale, Zap, Share2, Image as ImageIcon, Loader2, Lock } from 'lucide-react';

interface IdeaCardProps {
  idea: AppIdea;
  onAnalyze: (idea: AppIdea) => void;
  isSelected: boolean;
  isSaved: boolean;
  onToggleSave: (idea: AppIdea) => void;
  isCompareSelected: boolean;
  onToggleCompare: (idea: AppIdea) => void;
  disableCompareSelect: boolean;
  onShare: (idea: AppIdea) => void;
  onGenerateImage: (idea: AppIdea) => Promise<void>;
  isGeneratingImage: boolean;
  isAnalyzing: boolean;
  isProMember: boolean;
}

// Optimized to generate a consistent hue based on the category string itself.
// This allows the AppCategory list to expand indefinitely without needing to update this switch case.
const getGradient = (category: string, title: string) => {
  // Hash the category to get a base hue
  let catHash = 0;
  for (let i = 0; i < category.length; i++) {
    catHash = category.charCodeAt(i) + ((catHash << 5) - catHash);
  }
  const baseHue = Math.abs(catHash % 360);

  // Hash the title to get a slight variation (secondary hue)
  let titleHash = 0;
  for (let i = 0; i < title.length; i++) {
    titleHash = title.charCodeAt(i) + ((titleHash << 5) - titleHash);
  }
  const variance = Math.abs(titleHash % 40); // 0-40 degree shift

  // Generate gradient using HSL for dynamic but harmonious colors
  return `linear-gradient(135deg, hsl(${baseHue}, 70%, 20%) 0%, hsl(${(baseHue + variance + 20) % 360}, 70%, 15%) 100%)`;
};

export const IdeaCard: React.FC<IdeaCardProps> = ({ 
  idea, 
  onAnalyze, 
  isSelected, 
  isSaved, 
  onToggleSave, 
  isCompareSelected, 
  onToggleCompare, 
  disableCompareSelect, 
  onShare, 
  onGenerateImage, 
  isGeneratingImage, 
  isAnalyzing,
  isProMember
}) => {
  const gradient = getGradient(idea.category, idea.title);

  return (
    <div 
      className={`
        relative overflow-hidden rounded-2xl border transition-all duration-300 group cursor-pointer flex flex-col
        hover:scale-[1.02] hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.1)] dark:hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.8)]
        ${isSelected 
          ? 'bg-white dark:bg-neutral-900 border-red-600 shadow-[0_0_20px_rgba(220,38,38,0.2)]' 
          : 'bg-white dark:bg-neutral-900/60 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-500 hover:bg-neutral-50 dark:hover:bg-neutral-900'}
      `}
      onClick={() => !isAnalyzing && onAnalyze(idea)}
    >
      {/* Image Area */}
      <div className="h-44 w-full relative overflow-hidden bg-neutral-900 group/image">
        {idea.imageUrl ? (
          <img src={idea.imageUrl} alt={idea.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        ) : (
          <div 
            className="w-full h-full flex items-center justify-center relative"
            style={{ background: gradient }}
          >
             <div className="absolute inset-0 opacity-20" style={{ 
                backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)',
                backgroundSize: '20px 20px' 
             }}></div>
             <div className="text-white/20 font-black text-6xl uppercase tracking-tighter mix-blend-overlay select-none">
                {idea.title.substring(0, 2)}
             </div>
          </div>
        )}

        {/* Generate Image Button (Overlay) */}
        {!idea.imageUrl && (
            <button
                onClick={(e) => {
                    e.stopPropagation();
                    onGenerateImage(idea);
                }}
                disabled={isGeneratingImage}
                className="absolute inset-0 m-auto w-fit h-fit px-4 py-2 bg-black/60 hover:bg-black/80 backdrop-blur-sm border border-white/20 rounded-full text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 opacity-0 group-hover/image:opacity-100 transition-all duration-300 hover:scale-105 active:scale-95 disabled:opacity-80 disabled:cursor-wait"
            >
                {isGeneratingImage ? <Loader2 size={14} className="animate-spin" /> : (
                    isProMember ? <ImageIcon size={14} /> : <Lock size={14} className="text-yellow-400" />
                )}
                {isGeneratingImage ? 'Generating Art...' : (isProMember ? 'Generate Concept Art' : 'Unlock Concept Art')}
            </button>
        )}
        
        {/* Overlay Gradient for Text Readability at bottom */}
        <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-black/80 to-transparent pointer-events-none opacity-60"></div>

        {/* Action Buttons */}
        <div className="absolute top-3 right-3 flex gap-2 z-20">
             {/* Share Button */}
            <button
                onClick={(e) => {
                    e.stopPropagation();
                    onShare(idea);
                }}
                className="p-1.5 rounded-md bg-black/40 hover:bg-black/70 text-white/70 hover:text-white backdrop-blur-md border border-white/10 transition-all duration-200"
                title="Share"
            >
                <Share2 size={14} />
            </button>

            {/* Compare Button */}
            <button
            onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(idea);
            }}
            disabled={!isCompareSelected && disableCompareSelect}
            className={`
                p-1.5 rounded-md backdrop-blur-md border transition-all duration-200
                ${isCompareSelected
                    ? 'bg-red-600 text-white border-red-500 shadow-[0_0_10px_rgba(220,38,38,0.4)]'
                    : 'bg-black/40 hover:bg-black/70 text-white/70 hover:text-white border-white/10'
                }
                ${(!isCompareSelected && disableCompareSelect) ? 'opacity-30 cursor-not-allowed' : ''}
            `}
            title="Compare"
            >
                <Scale size={14} />
            </button>

            {/* Save Button */}
            <button
                onClick={(e) => {
                e.stopPropagation();
                onToggleSave(idea);
                }}
                className={`
                    p-1.5 rounded-md backdrop-blur-md border transition-all duration-200
                    ${isSaved 
                        ? 'bg-red-600 text-white border-red-500 shadow-[0_0_10px_rgba(220,38,38,0.4)]' 
                        : 'bg-black/40 hover:bg-black/70 text-white/70 hover:text-white border-white/10'
                    }
                `}
                title="Save"
            >
                <Heart size={14} fill={isSaved ? "currentColor" : "none"} />
            </button>
        </div>

        {/* Category Badge - Now over image */}
        <div className="absolute top-3 left-3 z-20">
             <span className="px-2 py-1 text-[10px] uppercase font-bold tracking-wider rounded bg-black/50 backdrop-blur-md text-white border border-white/10 shadow-sm">
                {idea.category}
            </span>
        </div>
      </div>

      {/* Content Body */}
      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-bold text-neutral-900 dark:text-white uppercase tracking-wide leading-tight line-clamp-1 flex-1 pr-4">{idea.title}</h3>
            
            {/* Virality Score with Tooltip */}
            <div className="relative group cursor-help flex items-center gap-1 text-yellow-600 dark:text-yellow-500 text-xs font-bold font-mono shrink-0 bg-yellow-100 dark:bg-yellow-900/30 px-1.5 py-0.5 rounded border border-yellow-200 dark:border-yellow-900/50 z-10">
                <TrendingUp size={12} />
                <span>{idea.viralityScore}</span>
                
                {/* Tooltip */}
                <div className="absolute top-full right-0 mt-2 w-48 bg-neutral-950 dark:bg-neutral-950 backdrop-blur text-white text-[10px] font-sans font-medium p-3 rounded-xl shadow-xl border border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none invisible group-hover:visible z-20 translate-y-1 group-hover:translate-y-0">
                    <div className="text-yellow-500 font-bold mb-1 text-[10px] uppercase tracking-wider">Viral Coefficient</div>
                    <p className="text-neutral-200 leading-relaxed font-normal normal-case tracking-normal">Propensity for organic growth via user-to-user invites (K-Factor).</p>
                    {/* Arrow tip */}
                    <div className="absolute -top-1 right-3 w-2 h-2 bg-neutral-950 rotate-45 border-l border-t border-white/10"></div>
                </div>
            </div>
        </div>

        <p className="text-neutral-600 dark:text-neutral-400 text-xs mb-4 line-clamp-1 font-mono uppercase tracking-tight">{idea.tagline}</p>
        
        <p className="text-neutral-700 dark:text-neutral-200 text-sm mb-6 leading-relaxed font-light line-clamp-3">
            {idea.description}
        </p>

        <div className="grid grid-cols-2 gap-3 mt-auto mb-5">
            <div className="bg-neutral-50 dark:bg-black p-3 rounded-lg border border-neutral-200 dark:border-neutral-800">
            <div className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 text-[10px] uppercase tracking-wider mb-1 font-bold">
                <Users size={12} />
                <span>Proj. Users</span>
            </div>
            <span className="text-yellow-600 dark:text-yellow-500 font-mono text-lg font-bold">
                {(idea.estimatedYearOneUsers / 1000000).toFixed(1)}M
            </span>
            </div>
            
            {/* Ad Revenue with Tooltip */}
            <div className="bg-neutral-50 dark:bg-black p-3 rounded-lg border border-neutral-200 dark:border-neutral-800 relative group/ad">
            <div className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 text-[10px] uppercase tracking-wider mb-1 font-bold relative group cursor-help w-fit">
                <DollarSign size={12} />
                <span>Ad Pot.</span>

                 {/* Tooltip */}
                 <div className="absolute bottom-full left-0 mb-2 w-48 bg-neutral-950 dark:bg-neutral-950 backdrop-blur text-white text-[10px] font-sans font-medium p-3 rounded-xl shadow-xl border border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none invisible group-hover:visible z-20 translate-y-1 group-hover:translate-y-0">
                    <div className="text-red-500 font-bold mb-1 text-[10px] uppercase tracking-wider">Monetization Power</div>
                    <p className="text-neutral-200 leading-relaxed font-normal normal-case tracking-normal">Estimated efficiency based on category-specific eCPM and fill rates.</p>
                     {/* Arrow tip */}
                     <div className="absolute -bottom-1 left-3 w-2 h-2 bg-neutral-950 rotate-45 border-b border-r border-white/10"></div>
                </div>
            </div>
            <div className="w-full bg-neutral-200 dark:bg-neutral-800 h-2 rounded-full mt-2 overflow-hidden">
                <div 
                className="bg-red-600 h-full rounded-full" 
                style={{ width: `${idea.adRevenuePotential}%` }}
                ></div>
            </div>
            </div>
        </div>

        {/* Quick Analyze Button */}
        <button
            onClick={(e) => {
            e.stopPropagation();
            onAnalyze(idea);
            }}
            disabled={isAnalyzing}
            className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-800 dark:from-red-800 dark:to-red-600 text-white text-xs font-bold uppercase tracking-widest transition-all duration-200 border-2 border-red-500/50 dark:border-neutral-400/60
            ${isAnalyzing 
                ? 'opacity-80 cursor-wait' 
                : 'hover:from-red-500 hover:to-red-700 dark:hover:from-red-700 dark:hover:to-red-500 hover:scale-[1.02] shadow-lg hover:shadow-[0_0_20px_rgba(220,38,38,0.4)] active:scale-95'
            }`}
        >
            {isAnalyzing ? (
                <>
                    <Loader2 size={14} className="animate-spin" />
                    Analyzing Data...
                </>
            ) : (
                <>
                    <Zap size={14} className="fill-white" />
                    Analyze Diagnostics
                </>
            )}
        </button>
      </div>
    </div>
  );
};